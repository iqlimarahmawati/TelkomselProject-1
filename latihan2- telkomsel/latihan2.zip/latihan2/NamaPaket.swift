//
//  NamaPaket.swift
//  latihan2
//
//  Created by Phincon on 16/02/23.
//

import Foundation

struct NamaPaketModel {
    var paket: String = ""
    var durasi: String = ""
    var hargaAsli: String = ""
    var hargaDiskon: String = ""
    var jenisPaket: String = ""
}
